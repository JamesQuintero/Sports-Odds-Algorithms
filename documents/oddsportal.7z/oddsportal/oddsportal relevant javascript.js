function CouponHandler() {
    this.init = function() {
        EventManager.register('onPageReady', function() {
            globals.ch.render()
        })
    };
    this.render = function(element) {
        var els;
        if (element) {
            els = [element]
        } else {
            els = $('[xodd]')
        }
        var oddsFormatClass = (globals.oddsFormat == 2) ? ' class="uk"' : '';
        for (var i = 0; i < els.length; i++) {
            var obj = $(els[i]);
            var xoid = obj.attr('xoid');
            var oddSpl = globals.d(obj.attr('xodd')).split('|');
            var odd = '';
            if (oddSpl.length == 1) {
                odd = oddSpl[0]
            } else {
                if (globals.prefferedOdds == 1) {
                    odd = oddSpl[0]
                } else {
                    odd = oddSpl[1]
                }
            }
            if (oddSpl[2] && oddSpl[2] == 'D') {
                obj.addClass('disabled')
            } else {
                obj.removeClass('disabled')
            }
            if (!xoid) {
                obj.html(globals.formatOdd(odd, true, '-'))
            } else if (obj.hasClass('live') || xoid == '-' || obj.hasClass('deactivateOdd')) {
                obj.html('<span' + oddsFormatClass + '>' + globals.formatOdd(odd, true, '-') + '</span>')
            } else {
                obj.html('<a href="" onclick="globals.ch.togle(this , \'' + xoid + '\');return false;" xparam="odds_text"' + oddsFormatClass + '>' + globals.formatOdd(odd, true, '-') + '</a>')
            }
        }
    };
};
globals.ch = new CouponHandler();





function Globals() {
    this.d = function(str) {
            str = str.replace(/a/g, 1).replace(/x/g, 2).replace(/c/g, 3).replace(/t/g, 4).replace(/e/g, 5).replace(/o/g, 6).replace(/p/g, 7).replace(/z/g, '.').replace(/f/g, '|');
            return str
        };

    this.formatOdd = function(num, returnOne, returnOneString) {
        if (!num) return '';
        num = num * 1;
        if (num > 0.999 && num < 1.001) {
            if (returnOne) {
                return returnOneString ? returnOneString : '1.00'
            } else {
                return ''
            }
        }
        if (globals.oddsFormat == 1) {
            return globals.formatTwodigits(num)
        } else if (globals.oddsFormat == 2) {
            return globals.formatUk(num)
        } else if (globals.oddsFormat == 3) {
            return globals.formatUs(num)
        } else if (globals.oddsFormat == 4) {
            return globals.formatHk(num)
        } else if (globals.oddsFormat == 5) {
            return globals.formatMa(num)
        } else if (globals.oddsFormat == 6) {
            return globals.formatIn(num)
        }
    };

    this.formatUs = function(decimal) {
        if (decimal >= 2) {
            return '+' + Math.floor((decimal - 1) * 100)
        } else if (decimal != 1) {
            return -Math.round(100 / (decimal - 1))
        } else {
            return 'N/A'
        }
    };

    this.formatTwodigits = function(num) {
        dnum = Math.round(num * 100) / 100;
        twoDPString = dnum + "";
        if (twoDPString.indexOf(".") == -1) {
            twoDPString += ".00"
        }
        if (twoDPString.indexOf(".") == twoDPString.length - 2) {
            twoDPString += "0"
        }
        return twoDPString
    };