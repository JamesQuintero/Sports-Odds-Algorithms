

def decode(string):

	new_string=string.replace("a", "1").replace("x", "2").replace("c", "3").replace("t", "4").replace("e", "5").replace("o", "6").replace("p", "7").replace("z", '.').replace("f", '|')
	print("Old string: "+str(string))
	print("New string: "+str(new_string))

	split=new_string.split("|")
	print("Format: "+str(formatUS(float(split[0])))+" | "+str(formatUS(float(split[1]))))

def formatUS(number):
	if (number >= 2):
		return int((number - 1) * 100)
	elif (number != 1):
		return -int(100 / (number - 1))
	else:
		return 0
	
 # return number

# decode("azt8faztt")
decode("cz08fxz9")